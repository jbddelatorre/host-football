<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParticipantTournament extends Model
{
    protected $table = 'participants_tournaments';
}
