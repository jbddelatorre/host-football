<h2>My Registered Tournaments</h2>
<div class="row">
	<div class="col sm-12">
		<?php if(count($my_tournaments) == 0): ?>
			<div class="card bg-faded my-3 pt-2">
				<div class="card-body">
					<div class="row align-items-center justify-content-center">
						<h6>No registered Tournaments</h6>
					</div>
				</div>
			</div>
		<?php else: ?>
			<?php $__currentLoopData = $my_tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card bg-faded my-3 pt-2">
				<div class="card-body">
					<div class="row align-items-center">
						<div class="col-sm-2">
							<img style="width:100%; max-height:25%;" src="<?php echo e(asset($t->image_path)); ?>" alt="Tournament poster">
						</div>
						<div class="col-sm-3">
							<p>Tournament Name</p>
							<h6 class="card-title t-info-header"><?php echo e($t->name); ?></h6>
							<p>Location</p>
							<h6 class="card-title t-info-header"><?php echo e($t->location); ?></h6>
							<p>Date</p>
							<h6 class="card-title t-info-header">
								<?php if($t->date_start == $t->date_end): ?>
									<?php echo e($t->date_start); ?>

								<?php else: ?>
									<?php echo e($t->date_start); ?> to <?php echo e($t->date_end); ?>

								<?php endif; ?>
							</h6>	
						</div>
						<div class="col-sm-4">
							<div class="row my-2">
								<div class="col-sm-4">
									Team Name
								</div>
								<div class="col-sm-8 subcat-content">
									Division
								</div>
							</div>
							<ul style="list-style-type: none; padding-left: 10px;">
								<?php $__currentLoopData = $registeredTeams[$t->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<div class="row">
											<div class="col-sm-4">
												<?php echo e($team['teamname']); ?>

											</div>
											<div class="col-sm-8 subcat-content">
												<?php echo e($team['data']); ?>

											</div>
										</div>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
						<div class="col-sm-3 ">
							<div class="row justify-content-center">
								<form action="/participant/viewregistration/<?php echo e($t->id); ?>" method="GET">
									<?php echo csrf_field(); ?>
									<button class="btn btn-outline-primary">View Team Registration</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</div>
</div>