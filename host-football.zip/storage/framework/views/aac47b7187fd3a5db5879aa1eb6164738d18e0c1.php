<?php $__env->startSection('content'); ?>
	<div class="container">
		<h2>Edit Tournament</h2>
		<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="card">
			<div class="card-body">
				<form id="formRegisterTournament" method="POST" action="/host/submitedittournament/<?php echo e($tournament->id); ?>" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<input type="text" hidden name="edit" value="edittournament">
			<div class="row">
				<div class="col-sm-8">
					<div class="form-group">
						<label for="name">Tournament Name</label>
						<input type="text" class="form-control" id="name" name="name" value="<?php echo e($tournament->name); ?>">
						<small class="form-text text-muted">Enter desired name</small>
					</div>
					<div class="form-group">
						<label for="location">Tournament Location</label>
						<input type="text" class="form-control" id="location" name="location" value="<?php echo e($tournament->location); ?>">
						<small class="form-text text-muted">Enter location</small>
					</div>
					<div class="form-group">
						<label for="startdate">Start Date</label>
						<input type="date" class="form-control" id="startdate" name="startdate">
					</div>
					<div class="checkbox">
							<label><input style="margin-right:10px;" type="checkbox" id="sameDayCheckbox" value="0" name="onedaytournament">One-day Tournament</label>
					</div>
					<div class="form-group">
						<label for="enddate">End Date</label>
						<input type="date" class="form-control" id="enddate" name="enddate">
					</div>
					<div class="form-group">
						<label for="poster">Upload Poster</label>
						<input type="file" class="form-control-file" id="poster" name="poster">
					</div>
					<div class="form-group">
						<img style="width:200px;" src="<?php echo e(asset($tournament->image_path)); ?>" alt="Current Tournament Image">
						<p>Current Tournament Image</p>
					</div>
				</div>
				<div class="col-sm-4">
					<label for="name">Divisions</label>
					<?php for($x = 10; $x <= 18; $x++): ?>
						<div class="checkbox">
							<label><input style="margin-right:10px;" type="checkbox" id="under<?php echo e($x); ?>" value="U<?php echo e($x); ?>" name="subcategories[]"
								<?php $__currentLoopData = $tournament->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($sub->id == 'U'.$x): ?>
										<?php echo e('checked'); ?>

									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							>Under <?php echo e($x); ?></label>
						</div>
					<?php endfor; ?>
					<div class="checkbox">
							<label><input style="margin-right:10px;" type="checkbox" id="MO" value="MO" name="subcategories[]"
								<?php $__currentLoopData = $tournament->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($sub->id == 'MO'): ?>
										<?php echo e('checked'); ?>

									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							>Men's Open</label>
					</div>
				</div>
			</div>
			<div class="row mt-4 my-4">
				<div class="col-xs-12" style="margin: 0 auto;">
					<button type="submit" class="btn btn-outline-primary">Edit my Tournament</button>
				</div>
			</div>
		</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<script>
	window.onload = () => {
		// Disables end-date when one-day tournament is checked
		const sameDayCheckbox = document.querySelector('#sameDayCheckbox')
		const endDateInput = document.querySelector('#enddate')
		
		
		sameDayCheckbox.addEventListener("click", (e) => {
			sameDayCheckbox.value = 1 - e.target.value;

			if (sameDayCheckbox.value == 1) {
				endDateInput.setAttribute("disabled", true)
			} else {
				endDateInput.removeAttribute("disabled", '')
			}
		})
	}

</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>