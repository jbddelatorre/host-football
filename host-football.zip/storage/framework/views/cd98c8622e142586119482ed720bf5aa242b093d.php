<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e('Host Football'); ?></title>

    
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>">
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    
    
    <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('js/message.js')); ?>"></script>

    <style>
        #app {
        }
        .margin-top-navbar {
            min-height: 100vh !important;
            margin-top: 90px;
        }

        .hide-view {
            display: none !important;
        }

        .dropdown-menu a:active {
            background-color: #eee !important;
            color:#000;
        }
        .navbar {
            z-index: 9999;
            display: block;
            opacity: 0.95;
            transition: all 0.5s ease-in;
        }

        .navbar-trans {
            background-color: transparent !important;
            background: transparent !important;
            border-color: transparent !important;
            /*display: none;*/
        }

        .t-info-header {
            font-weight: 600; 
            padding-left: 12px;
            font-size: 16px;
         }
         .t-info {
            font-size: 16px;
         }

        .fixed-nav {
            position: fixed;
            top:0;
            width:100vw;
        }
        .navbar-brand {
            font-size: 24px;
        }
        
        .navbar .nav-button {
            color:white !important;
        }

        .card-header {
            background-color: #76b852;
            color:white;
            letter-spacing: 2px;
            font-size: 18px;
        }
        .alert {
            transition: all 1.5s ease-out;
            text-align: center;
        }

        footer {
            text-align: center;
            background-color: #1f0a2e;
            color:white;
        }
        footer p {
            padding: 16px 0;
            margin:0;
        }
    </style>

</head>
<body>
    <div id="app">
        <nav id="appNav" class="wow fadeIn navbar navbar-expand-md navbar-dark bg-dark navbar-laravel fixed-nav">
            <div class="container animated slideInUp ">
                <a class="navbar-brand navbar-font" href="<?php echo e(url('/')); ?>">
                   <?php echo e('HOST FOOTBALL'); ?>

                    
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="btn btn-outline-secondary nav-button" href="<?php echo e(route('login')); ?>" style="border:none;"><?php echo e(__('Login')); ?></a>
                            </li>
                            <li class="nav-item">
                                <?php if(Route::has('register')): ?>
                                    <a class="btn btn-outline-secondary nav-button" role="button" href="<?php echo e(route('register')); ?>" style="border:none;"><?php echo e(__('Register')); ?></a>
                                <?php endif; ?>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="btn btn-outline-secondary nav-button" href="
                                 <?php if(Auth::user()->user_type_id == 1): ?>
                                        <?php echo e('/host'); ?>

                                    <?php else: ?>
                                        <?php echo e('/participant'); ?>

                                    <?php endif; ?>
                                " role="button" style="border:none;">
                                    Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <div class="dropdown">
                                  <button class="btn btn-outline-secondary dropdown-toggle nav-button" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border:none;">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                  </button>
                                  <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                  </div>
                                </div>    
                            </li>


                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        

        <?php echo $__env->yieldContent('landing'); ?>
        
        <main class="margin-top-navbar">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <footer>
            <p>Copyright &copy; 2018 &middot; Developed by Host Football</p>
        </footer>
    </div>
</body>
<script>new WOW().init();</script>

</html>
