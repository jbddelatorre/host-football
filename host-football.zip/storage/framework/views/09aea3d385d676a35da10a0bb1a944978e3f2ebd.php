<style>
	.status-content {
		font-weight: 300;
		letter-spacing: 2px;
	}
	.team-list hr {
		margin: 8px 0;
	}
	.team-title p {
		margin-bottom: 8px;
	}
	.team-title h5 {
		margin-top: 16px;
	}

	.accepted {
		color:#42c742 !important;
	}
	.pending {
		color:#ef9509b5 !important;
	}
	.rejected {
		color:#ff0000 !important;
	}
</style>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-sm-3"><h5>Tournament Name</h5></div>
			<div class="col-sm-9"><h5><?php echo e($tournament->name); ?></h5></div>
		</div>
		<div class="row">
			<div class="col-sm-3"><h5>Location</h5></div>
			<div class="col-sm-9"><h5><?php echo e($tournament->location); ?></h5></div>
		</div>
		<div class="row">
			<div class="col-sm-3"><h5>Date</h5></div>
			<div class="col-sm-9"><h5>
				<?php if($tournament->date_start == $tournament->date_end): ?>
					<?php echo e($tournament->date_start); ?>

				<?php else: ?>
					<?php echo e($tournament->date_start); ?> to <?php echo e($tournament->date_end); ?>

				<?php endif; ?>
			</h5></div>
		</div>
		<div class="row">
			<div class="col-sm-3"><h5>Organization</h5></div>
			<div class="col-sm-9"><h5><?php echo e($organization); ?></h5></div>
		</div>

		<div class="row justify-content-end">
			<div class="col-sm-12 my-2">
				<a class="btn btn-outline-success float-right" href="/participant">Return to Dashboard</a>
			</div>
		</div>

		<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="row">
			<div class="col sm-12">
				<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="card bg-faded my-3 pt-2">
						<div class="card-body">
							<div class="row align-items-center">
								<div class="col-sm-12 col-md-3 team-title">
									<p>Team Name</p>
									<h6 class="t-info-header"><?php echo e($team->team_name); ?></h6>
									<p>Division</p>
									<h6 class="t-info-header subcat-content"><?php echo e($team->subcategory_id); ?></h6>
									<p>Name of Coach</p>
									<h6 class="t-info-header"><?php echo e($team->coach_name); ?></h6>
									<p>Contact Number</p>
									<h6 class="t-info-header"><?php echo e($team->mobile_number); ?></h6>
									<p>Registration Status</p>
									<h6 class="t-info-header status-content"><?php echo e($team->team_registration_status); ?></h6>
								</div>
								<div class="col-sm-12 col-md-6 team-list">
									<div class="row my-2">
										<div class="col-sm-6">
											Player Names
										</div>
										<div class="col-sm-6 subcat-content">
											Date of Birth
										</div>
									</div>
									<ul style="list-style-type: none; padding-left: 10px;">
										<hr>
										<?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li style="padding-left: 12px;">
												<div class="row">
													<div class="col-sm-6">
														<?php echo e($player['name']); ?>

													</div>
													<div class="col-sm-6">
														<?php echo e($player['date_of_birth']); ?>

													</div>
												</div>
											</li>
											<hr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</div>

								<div class="col-sm-3 ">
									<div class="row justify-content-center">
										<form action="/participant/editregistration/<?php echo e($team->id); ?>" method="GET">
											<?php echo csrf_field(); ?>
											<button type="submit" class="btn btn-outline-primary">Edit Team Registration</button>
										</form>
											<button type="submit" class="btn btn-outline-danger" data-toggle="modal" data-target="#delete<?php echo e($team->id); ?>">Delete Team Registration</button>
										
										
											<div class="modal fade" id="delete<?php echo e($team->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
											  <div class="modal-dialog" role="document" style="transform:translateY(50%);">
											    <div class="modal-content">
											      <div class="modal-header">
											        <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
											        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
											          <span aria-hidden="true">&times;</span>
											        </button>
											      </div>
											      <div class="modal-body">
											        Are you sure you want to delete this team?
											      </div>
											      <div class="modal-footer">
													<form action="/participant/deleteteam/<?php echo e($team->id); ?>" method="POST">
														<?php echo csrf_field(); ?>
														<?php echo method_field('DELETE'); ?>
														<input type="number" hidden name="tournamentId" value=<?php echo e($team->tournament_id); ?>>
												        <button type="submit" class="btn btn-outline-danger">Delete</button>
													</form>
											      </div>
											    </div>
											  </div>
											</div>
										
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<script>
	window.onload = () => {
		//Convert subcategories to labelled divisions
		const convertSubcategory = (id) => {
			switch(id) {
				case 'U10':
					return "Under-10 Division"
					break;
				case 'U11':
					return "Under-11 Division"
					break;
				case 'U12':
					return "Under-12 Division"
					break;
				case 'U13':
					return "Under-13 Division"
					break; 
				case 'U14':
					return "Under-14 Division"
					break; 
				case 'U15':
					return "Under-15 Division"
					break; 
				case 'U16':
					return "Under-16 Division"
					break; 
				case 'U17':
					return "Under-17 Division"
					break; 
				case 'U18':
					return "Under-18 Division"
					break;
				case 'MO':
					return "Men's Open Division"
					break;
				default:
					return id;     
			}
		}

		const subcatDom = document.querySelectorAll('.subcat-content');
		subcatDom.forEach((s) => {
			s.textContent = convertSubcategory(s.textContent.trim());
		})

		//Team status update
		const convertTeamStatus = (status) => {
			switch(status) {
				case 'A':
					return 'Approved';
					break;
				case 'R':
					return 'Rejected';
					break;
				case 'P':
					return 'Pending';
					break;
				default:
					return 'Undefined';
			}
		}
		
		const transformTeamStatus = () => {
			const statusDom = document.querySelectorAll('.status-content')
			statusDom.forEach(s => {
				const stat = s.textContent;

				if(stat == 'A') {
					s.classList.add('accepted');
				} 
				if (stat == 'R') {
					s.classList.add('rejected')
				} 
				if (stat == 'P') {
					s.classList.add('pending')
				}
				
				s.textContent = convertTeamStatus(s.textContent);
			})
		}

		transformTeamStatus();
	}
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>