<h2>Ongoing Tournaments</h2>
<div class="row">
	<div class="col sm-12">
		<?php $__currentLoopData = $ongoing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card bg-faded my-3 pt-2">
				<div class="card-body">
					<div class="row align-items-center">
						<div class="col-sm-2">
							<img style="width:100%; max-height:25%;" src="<?php echo e(asset($o->image_path)); ?>" alt="Tournament poster">
						</div>
						<div class="col-sm-5">
							<h6>Tournament Name</h6>
							<p class="t-info-header"><?php echo e($o->name); ?></p>
							<h6>Location:</h6>
							<p class="t-info-header"> <?php echo e($o->location); ?> </p>
							<h6>Date:</h6>
							<p class="t-info-header">
								<?php if($o->date_start == $o->date_end): ?>
									<?php echo e($o->date_start); ?>

								<?php else: ?>
									<?php echo e($o->date_start); ?> to <?php echo e($o->date_end); ?>

								<?php endif; ?>
							</p>
						</div>
						<div class="col-sm-5">
							<form action="/participant/tournamentdashboard/<?php echo e($o->id); ?>" method="GET">
								<?php echo csrf_field(); ?>
								<button type="submit" class="btn btn-outline-primary">Enter Tournament Dashboard</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>