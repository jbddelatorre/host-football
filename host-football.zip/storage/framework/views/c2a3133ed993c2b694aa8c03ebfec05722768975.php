<h2>Tournament List</h2>
<div class="row">
	<div class="col sm-12">
		<?php if(count($tournaments) == 0): ?>
			<div class="card bg-faded my-3 pt-2">
				<div class="card-body">
					<div class="row">
						<div class="col-sm-12 text-center">
							There are currently no available tournaments as of now.
						</div>
					</div>
				</div>
			</div>
		<?php else: ?>
		<?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card bg-faded my-3 pt-2">
				<div class="card-body">
					<div class="row align-items-center">
						<div class="col-sm-2">
							<img style="width:100%; max-height:25%;" src="<?php echo e(asset($t->image_path)); ?>" alt="Tournament poster">
						</div>
						<div class="col-sm-3">
							<p>Tournament Name</p>
							<h6 class="card-title t-info-header"><?php echo e($t->name); ?></h6>
							<p>Location</p>
							<h6 class="card-title t-info-header"><?php echo e($t->location); ?></h6>
							<p>Date</p>
							<h6 class="card-title t-info-header">
								<?php if($t->date_start == $t->date_end): ?>
									<?php echo e($t->date_start); ?>

								<?php else: ?>
									<?php echo e($t->date_start); ?> to <?php echo e($t->date_end); ?>

								<?php endif; ?>
							</h6>	
						</div>
						<div class="col-sm-4">
							<h6 class="card-title">Divisions</h6>
							<ul style="list-style-type: none;">
								<?php $__currentLoopData = $findTournament_ids[$t->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li class="subcat-content"><?php echo e($subcat); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
						<div class="col-sm-3 ">
							<div class="row justify-content-center">
								<form method="GET" action="/participant/registration/<?php echo e($t->id); ?>">
									<button type="submit" class="btn btn-outline-primary">Register</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</div>
</div>
