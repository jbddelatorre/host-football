
<div class="row tournament-table-div">
	<div class="col-sm-12 mb-3">
		<div class="row">
			
			<h3>Group A Table</h3>
			<div class="col-sm-12 table-responsive">
				<table class="table table-bordered table-hover">
					<thead>
						<tr>
							<th class="table-team-name">Team Name</th>
							<th class="table-organization">Organization</th>
							<th>P</th>
							<th>W</th>
							<th>D</th>
							<th>L</th>
							<th>GF</th>
							<th>GA</th>
							<th>GD</th>
							<th>PTS</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $group_tables[$subcat->id]["A"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($team_info[$team]['team_name']); ?></td>
								<td>
									<?php echo e($team_info[$team]['organization']); ?>

								</td>
								<td><?php echo e($data['played']); ?></td>
								<td><?php echo e($data['wins']); ?></td>
								<td><?php echo e($data['draws']); ?></td>
								<td><?php echo e($data['losses']); ?></td>
								<td><?php echo e($data['goals_for']); ?></td>
								<td><?php echo e($data['goals_against']); ?></td>
								<td><?php echo e($data['goal_difference']); ?></td>
								<td><?php echo e($data['points']); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>

			
			<h3>Group B Table</h3>
			<div class="col-sm-12 table-responsive">
				<table class="table table-bordered table-hover">
					<thead>
						<tr>
							<th class="table-team-name">Team Name</th>
							<th class="table-organization">Organization</th>
							<th>P</th>
							<th>W</th>
							<th>D</th>
							<th>L</th>
							<th>GF</th>
							<th>GA</th>
							<th>GD</th>
							<th>PTS</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $group_tables[$subcat->id]["B"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td>
									<?php echo e($team_info[$team]['team_name']); ?>

								</td>
								<td>
									<?php echo e($team_info[$team]['organization']); ?>

								</td>
								<td><?php echo e($data['played']); ?></td>
								<td><?php echo e($data['wins']); ?></td>
								<td><?php echo e($data['draws']); ?></td>
								<td><?php echo e($data['losses']); ?></td>
								<td><?php echo e($data['goals_for']); ?></td>
								<td><?php echo e($data['goals_against']); ?></td>
								<td><?php echo e($data['goal_difference']); ?></td>
								<td><?php echo e($data['points']); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<div class="col-sm-12 my-4">
		<div class="row">
			<div class="col-sm-6 text-center"><h4>Group A</h4></div>
			<div class="col-sm-6 text-center"><h4>Group B</h4></div>
		</div>
	</div>

	<div class="col-sm-12">
		<div class="row justify-content-center">
			<h5>Group A</h5>
		</div>
		<div class="row">
			<?php $__currentLoopData = $subcat->fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fixture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($fixture->group == 'A'): ?>
					<div class="col-sm-12">
						<div class="card my-2">
							<div class="card-header">
								<div class="row">
									<div class="col-sm-5">Group <?php echo e($fixture->group); ?> Match # <?php echo e($fixture->match_order); ?></div>
									<div class="col-sm-7 text-right">Fixture type: <span class="fixture-type"><?php echo e($fixture->fixture_type->fixture_type); ?></span></div>
								</div>
							</div>

							
							<div class="card-body text-center">
								<div class="row">
									
									<div class="col-sm-5">
										<div class="row">
											<div class="col-sm-8 text-center">
												<h5><?php echo e($team_info[$fixture->a_team]['team_name']); ?></h5>
												<p><?php echo e($team_info[$fixture->a_team]['organization']); ?></p>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
											    	<input disabled type="number" class="form-control" value="<?php echo e($fixture->a_score); ?>" data-score-A-id = <?php echo e($fixture->id); ?> min=0>
											    	<label>Score</label>
											 	 </div>
											</div>
										</div>
									</div>

									<div class="col-sm-2 text-center my-auto">VS</div>

									
									<div class="col-sm-5">
										<div class="row">
											<div class="col-sm-4">
												<div class="form-group">
											    	<input disabled type="number" class="form-control" value="<?php echo e($fixture->b_score); ?>" data-score-B-id = <?php echo e($fixture->id); ?> name="" min=0>
											    	<label>Score</label>
											 	 </div>
											</div>
											<div class="col-sm-8 text-center">
												<h5><?php echo e($team_info[$fixture->b_team]['team_name']); ?></h5>
												<p><?php echo e($team_info[$fixture->b_team]['organization']); ?></p>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12 text-center">
										<button class="btn btn-outline-info fixture-edit-button"  data-edit-fixture = "<?php echo e($fixture->id); ?>">Edit Score</button>
										<button class="btn btn-outline-success fixture-submit-button" data-fixture-id = "<?php echo e($fixture->id); ?>">Update Score</button>
									</div>
								</div>
							</div>

							<div class="card-footer" style="padding:5px 15px;">
								<div class="row">
									<div style="font-size:16px;"class="col-sm-12 text-right">
										Status: <span class="status-span"><?php echo e($fixture->fixture_status->fixture_status); ?></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>

	
	<div class="col-sm-12">
		<div class="row justify-content-center">
			<h5>Group B</h5>
		</div>
		<div class="row">
			<?php $__currentLoopData = $subcat->fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fixture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($fixture->group == 'B'): ?>
					<div class="col-sm-12">
						<div class="card my-2">
							<div class="card-header">
								<div class="row">
									<div class="col-sm-5">Group <?php echo e($fixture->group); ?> Match # <?php echo e($fixture->match_order); ?></div>
									<div class="col-sm-7 text-right">Fixture type: <span class="fixture-type"><?php echo e($fixture->fixture_type->fixture_type); ?></span></div>
								</div>
							</div>

							
							<div class="card-body text-center">
								<div class="row">
									
									<div class="col-sm-5">
										<div class="row">
											<div class="col-sm-8 text-center">
												<h5><?php echo e($team_info[$fixture->a_team]['team_name']); ?></h5>
												<p><?php echo e($team_info[$fixture->a_team]['organization']); ?></p>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
											    	<input disabled type="number" class="form-control" value="<?php echo e($fixture->a_score); ?>"name="" min=0 data-score-A-id = <?php echo e($fixture->id); ?>>
											    	<label>Score</label>
											 	 </div>
											</div>
										</div>
									</div>

									<div class="col-sm-2 text-center my-auto">VS</div>

									
									<div class="col-sm-5">
										<div class="row">
											<div class="col-sm-4">
												<div class="form-group">
											    	<input disabled type="number" value="<?php echo e($fixture->b_score); ?>"class="form-control" name="" min=0 data-score-B-id = <?php echo e($fixture->id); ?>>
											    	<label>Score</label>
											 	 </div>
											</div>
											<div class="col-sm-8 text-center">
												<h5><?php echo e($team_info[$fixture->b_team]['team_name']); ?></h5>
												<p><?php echo e($team_info[$fixture->b_team]['organization']); ?></p>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12 text-center">
										<button class="btn btn-outline-info fixture-edit-button"  data-edit-fixture = "<?php echo e($fixture->id); ?>">Edit Score</button>
										<button class="btn btn-outline-success fixture-submit-button" data-fixture-id = "<?php echo e($fixture->id); ?>">Update Score</button>
									</div>
								</div>
							</div>

							<div class="card-footer" style="padding:5px 15px;">
								<div class="row">
									<div style="font-size:16px;"class="col-sm-12 text-right">
										Status: <span class="status-span"><?php echo e($fixture->fixture_status->fixture_status); ?></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>

</div>