<h2>My Tournament History</h2>
<div class="row">
	<div class="col sm-12">

			<?php if(count($history) == 0): ?>
				<div class="card bg-faded my-3 pt-2">
					<div class="card-body">
						<div class="row">
							<div class="col-sm-12 text-center">
								There are currently no available tournaments as of now.
							</div>
						</div>
					</div>
				</div>
			<?php else: ?>
				<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="card bg-faded my-3 pt-2">
						<div class="card-body">
							<div class="row align-items-center">
								<div class="col-sm-2">
									<img style="width:100%; max-height:25%;" src="<?php echo e(asset($h->image_path)); ?>" alt="Tournament poster">
								</div>
								<div class="col-sm-7">
									<h6>Tournament Name</h6>
									<p class="t-info-header"><?php echo e($h->name); ?></p>
									<h6>Location:</h6>
									<p class="t-info-header"> <?php echo e($h->location); ?> </p>
									<h6>Date:</h6>
									<p class="t-info-header">
										<?php if($h->date_start == $h->date_end): ?>
											<?php echo e($h->date_start); ?>

										<?php else: ?>
											<?php echo e($h->date_start); ?> to <?php echo e($h->date_end); ?>

										<?php endif; ?>
									</p>
								</div>
								<div class="col-sm-3">
									<form action="/participant/gethistory/<?php echo e($h->id); ?>" method="GET">
										<?php echo csrf_field(); ?>
										<button type="submit" class="btn btn-outline-primary">Enter Tournament Dashboard</button>
									</form>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

	</div>
</div>