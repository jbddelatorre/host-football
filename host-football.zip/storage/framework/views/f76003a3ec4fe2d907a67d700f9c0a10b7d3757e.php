<?php $__env->startSection('content'); ?>

	<div class="container">
		<h2>Currently Registered Tournament</h2>
		
		<h2>Find a Tournament</h2>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>