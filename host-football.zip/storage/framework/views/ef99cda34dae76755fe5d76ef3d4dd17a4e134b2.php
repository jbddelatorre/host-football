<h2>Tournaments History</h2>

<div class="row">
	<div class="col-sm-12">
		<?php if(count($completed) == 0): ?>
			<div class="card bg-faded my-3 pt-2">
				<div class="card-body">
					<div class="row">
						<div class="col-sm-12 text-center">
							You do not have any completed tournament.
						</div>
					</div>
				</div>
			</div>
		<?php else: ?>
		<?php $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card bg-faded my-3 pt-2">
				<div class="card-body">
					<div class="row align-items-center">
						<div class="col-sm-2">
							<img style="width:100%; max-height:25%;" src="<?php echo e(asset($c->image_path)); ?>" alt="Tournament poster">
						</div>
						<div class="col-sm-5">
							<h6>Tournament Name</h6>
							<p class="t-info-header"> <?php echo e($c->name); ?></p>
							<h6>Location:</h6>
							<p class="t-info-header"> <?php echo e($c->location); ?> </p>
							<h6>Date:</h6>
							<p class="t-info-header">
								<?php if($c->date_start == $c->date_end): ?>
									<?php echo e($c->date_start); ?>

								<?php else: ?>
									<?php echo e($c->date_start); ?> to <?php echo e($c->date_end); ?>

								<?php endif; ?>
							</p>
						</div>
						<div class="col-sm-5">
							<form action="/host/tournamentdashboard/gethistory/<?php echo e($c->id); ?>" method="GET">
								<?php echo csrf_field(); ?>
								<button type="submit" class="btn btn-outline-primary">View Tournament History</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</div>
</div>