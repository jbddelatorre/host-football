<?php $__env->startSection('content'); ?>
	<div class="container">
		<h2>Team Registration Details</h2>
		<div class="row">
			<div class="col-sm-10">
				<div class="row">
					<div class="col-sm-3">Tournament Name:</div>
					<div class="col-sm-6"><?php echo e($tournament->name); ?></div>
				</div>
				<div class="row">
					<div class="col-sm-3">Subcategory:</div>
					<div class="col-sm-9"><?php echo e($subcat_id); ?></div>
				</div>
			</div>
			<div class="col-sm-2">
				<div class="row">
					<div class="col-sm-12 text-right">
						<a href="/host" class="btn btn-outline-primary">Return to Dashbaord</a>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<?php if(count($teams) == 0): ?>
				<div class="col-sm-12 text-center mt-4 pt-4">
					Subcategory has no registered teams.
				</div>
			<?php else: ?>
				<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-sm-6">
						<div class="card my-2">
							<div class="card-header">
								Team Name: <?php echo e($team->team_name); ?>

							</div>
							<div class="card-body">
								<p class="card-text">
									Organization: <?php echo e($team->user->organization); ?>	
								</p>
								<p class="card-text">
									Coach Name: <?php echo e($team->coach_name); ?>

								</p>
								<p class="card-text">
									Coach Number: <?php echo e($team->mobile_number); ?>	
								</p>
								<div class="row mb-3" style="padding-left: 10px;">
									<div class="col-sm-6">Player Names</div>
									<div class="col-sm-6">Date of Birth</div>
								</div>
								<?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="row" style="padding-left: 10px;">
										<div class="col-sm-6">
											<?php echo e($player->name); ?>

										</div>
										<div class="col-sm-6">
											<?php echo e($player->date_of_birth); ?>

										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>