<link rel="stylesheet" href="<?php echo e(asset('/css/register.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-12">
            <div class="form animated fadeInDown">

                    <form method="POST" class="login-form" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

 
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus placeholder="Full Name">

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>


                                <input id="organization" type="text" class="form-control<?php echo e($errors->has('organization') ? ' is-invalid' : ''); ?>" name="organization" value="<?php echo e(old('organization')); ?>" required autofocus placeholder="Organization">

                                <?php if($errors->has('organization')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('organization')); ?></strong>
                                    </span>
                                <?php endif; ?>



                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Email">

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>



                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password">

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>



                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm Password">

                        
                            <div class="my-4">
                            <span style="margin-right: 24px;"><?php echo e(__('Choose User Type')); ?></span>
                    
                                <input id="beHost" class="mr-2" type="radio" name="user_type_id" checked value="1" />
                                <label class="mr-4" for="beHost"><span></span>Be a Host</label>

                                <input id="bePart" class="mr-2" type="radio" name="user_type_id" value="2" />
                                <label class="radio-inline mr-4" for="bePart"><span></span>Join a Tournament</label>
                            </div>



                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
    
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>