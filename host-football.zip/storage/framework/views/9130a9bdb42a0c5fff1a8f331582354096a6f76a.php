<style>
	.error-image {
		width: 100%;

	}
</style>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row my-2">
			<div class="col-sm-12 text-center">
				<img class="error-image" src="<?php echo e(asset('/img/error.png')); ?>" alt="404 Page not found">
			</div>
		</div>
		<div class="row mt-4">
			<div class="col-sm-12 text-center">
				<p>We could not find the page your are looking for.</p>
			</div>
		</div>
		<div class="row mb-4">
			<div class="col-sm-12 text-center">
				<a href="/">Return to site</a>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>