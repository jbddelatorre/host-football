<style>
	.subcat-content {
	  display: inline-block;
	  width: 200px;
	  padding: 10px;
	  border: solid 2px #ccc;
	  transition: all 0.3s;
	  text-align: center;
	}

	form input[type="radio"] {
	  display: none;
	}

	form input[type="radio"]:checked + label {
	  border: solid 2px green;
	  color: green;
	  background-color: #e4ffeb;
	}

	.btn-circle.btn-xl {
    width: 70px;
    height: 70px;
    padding: 10px 16px;
    border-radius: 35px;
    font-size: 24px;
    line-height: 1.33;
	}

	.btn-circle {
	    width: 30px;
	    height: 30px;
	    padding: 6px 0px;
	    border-radius: 15px;
	    text-align: center;
	    font-size: 12px;
	    line-height: 1.42857;
	}
	.hide-button {
		display: none !important;
	}

</style>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<h2>Edit Tournament Registration</h2>
		
		<div class="row justify-content-end">
			<div class="col-sm-12 my-2">
				<a class="btn btn-outline-success float-right" href="/participant">Return to Dashboard</a>
			</div>
		</div>

		<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<form action="/participant/registration/<?php echo e($tournament->id); ?>" method="POST">
			<?php echo csrf_field(); ?>
		<div class="row">
			<input type="text" hidden name="tournamentId" value="<?php echo e($tournament->id); ?>">
			<input type="text" hidden name="teamId" value="<?php echo e($team->id); ?>">
			<div class="col sm-12">
				<div class="card bg-faded my-3 pt-2">
					<div class="card-body">
							<h6><?php echo e($tournament->name); ?></h6>
						<h6><?php echo e($tournament->location); ?></h6>
						<h6>
							<?php if($tournament->date_start == $tournament->date_end): ?>
								<?php echo e($tournament->date_start); ?>

							<?php else: ?>
								<?php echo e($tournament->date_start); ?> to <?php echo e($tournament->date_end); ?>

							<?php endif; ?>
						</h6>
					</div>

					<div class="card-body">
						<h6>Choose a division</h6>
						<input class="subcat-radio" type="radio" id="radio<?php echo e($team->subcategory_id); ?>"name="subcategory" value=<?php echo e($team->subcategory_id); ?>>
						<label class="subcat-content"for="radio<?php echo e($team->subcategory_id); ?>"><?php echo e($team->subcategory_id); ?></label>
					</div>
				
					<div class="card-body">
						<h6>Team Name</h6>
						<div class="form-group">
							<div class="row">
								<div class="col-sm-6">
									<input type="text" class="form-control <?php echo e($errors->has('teamname') ? 'is-invalid' : ''); ?>" id="teamName" name="teamname" value="<?php echo e($team->team_name); ?>">
									<div class="invalid-feedback">
										<?php echo e($errors->first('teamname')); ?>

									</div>
									
								</div>
							</div>
						</div>
					</div>
					
					<div class="card-body players-form-list" id="playerFillout">
						<h6>Team Members</h6>
						<div class="form-group">
							<div class="row">
								<div class="col-sm-7">
									<h6>Player Name</h6>
								</div>
								<div class="col-sm-5">
									<h6>Date of Birth</h6>
								</div>
							</div>
						</div>

						<div id="playerCountData" players-count=<?php echo e(count($players)); ?>></div>

						<?php if($errors->has('players')): ?>
							<div class="alert alert-danger">
								<?php echo e($errors->first('players')); ?>

							</div>
						<?php endif; ?>

								
						<?php for($i = 0; $i < count($players); $i++): ?>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-7">
										<input type="text" value="<?php echo e($players[$i]['name']); ?>" class="players-name form-control <?php echo e($errors->has('players.'.$i.'.name') ? 'is-invalid':''); ?>" name="players[<?php echo e($i); ?>][name]">

										<div class="invalid-feedback">
											<?php echo e($errors->first('players.'.$i.'.name')); ?>

										</div>
									</div>
									<div class="col-sm-5">
										<input type="date" id="date<?php echo e($i); ?>" class="players-date form-control <?php echo e($errors->has('players.'.$i.'.dob') ? 'is-invalid':''); ?>" name="players[<?php echo e($i); ?>][dob]" value=<?php echo e($players[$i]['date_of_birth']); ?>>
										<div class="invalid-feedback">
											<?php echo e($errors->first('players.'.$i.'.dob')); ?>

										</div>
									</div>
								</div>
							</div> 
						<?php endfor; ?>
					</div>
			
					<div class="card-body">
						<div class="row justify-content-center">
							<button id="formAdd" class="button-player-fillout btn btn-outline-primary mx-2">Add Player</button>
							<div class="col-sm-12 text-center hide-button" id="maxPlayers">
								<p>Maximum of 12 players only.</p>
							</div>
						</div>
					</div>
						
					<div class="card-body">
						<h6>Contact Person Details</h6>
						<div class="form-group">
							<div class="row">
								<div class="col-sm-2">
									<label for="coachName">Name of Coach</label>
								</div>
								<div class="col-sm-6">
									<input type="text" class="form-control" id="coachName" name="coachname" value="<?php echo e($team->coach_name); ?>">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-sm-2">
									<label for="coachMobile">Mobile Number</label>
								</div>
								<div class="col-sm-6">
									<input type="tel" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}" class="form-control" id="coachMobile" name="coachmobile" value=<?php echo e($team->mobile_number); ?>>
									<small class="form-text text-muted">Format: 0917-123-4567</small>
								</div>
							</div>
						</div>	
					</div>


					<div class="card-body">
						<div class="row justify-content-center">
							<button class="btn btn-outline-primary" type="submit">Edit Registration</button>
						</div>
					</div>

				</div>
			</div>
		</div>

		</form>

	</div>
<?php $__env->stopSection(); ?> 

<script>
	window.onload = () => {
	//Convert subcategories to labelled divisions
	const convertSubcategory = (id) => {
		switch(id) {
			case 'U10':
				return "Under-10 Division"
				break;
			case 'U11':
				return "Under-11 Division"
				break;
			case 'U12':
				return "Under-12 Division"
				break;
			case 'U13':
				return "Under-13 Division"
				break; 
			case 'U14':
				return "Under-14 Division"
				break; 
			case 'U15':
				return "Under-15 Division"
				break; 
			case 'U16':
				return "Under-16 Division"
				break; 
			case 'U17':
				return "Under-17 Division"
				break; 
			case 'U18':
				return "Under-18 Division"
				break;
			case 'MO':
				return "Men's Open Division"
				break;
			default:
				return id;     
		}
	}

	const subcatDom = document.querySelectorAll('label.subcat-content');
	subcatDom.forEach((s) => {
		s.textContent = convertSubcategory(s.textContent.trim());
	})

	//Set initial value of radio button input
	document.querySelector('.subcat-radio').checked = true

	//Manipulate Player form sheet

	// const addPlayerForm = (number) => {
	// 	$('#playerFillout').append(`
			
	// 	`)
	// }

	// for(let i = 0; i < 8; i++) {
	// 	addPlayerForm(i);
	// }


	//Add/Remove players Form

	const buttons = document.querySelectorAll('.button-player-fillout')
	const formAdd = document.querySelector('#formAdd')
	const formRemove = document.querySelector('#formRemove')

		//Remove default
	buttons.forEach((b) => {
		b.addEventListener("click", (e) => {
			e.preventDefault();
		})
	})
		
		//Add form functionality
	formAdd.addEventListener("click", () => {
		const playerCountDOM = document.querySelector('#playerCountData')
		const playerCount = playerCountDOM.getAttribute('data-players-count')

		$('.players-form-list').append(`
			<div class="form-group">
				<div class="row">
					<div class="col-sm-7">
						<input type="text" class="players-name form-control name="players[${playerCount - 1}][name] placeholder='Enter Full Name'">
					</div>
					<div class="col-sm-5">
						<input type="date" id="date${playerCount - 1}" class="players-date form-control" name="players[{${playerCount - 1}}][dob]">
					</div>
				</div>
			</div>
		`)

		const countname = document.querySelectorAll('.players-name').length
		const countdob = document.querySelectorAll('.players-date').length

		if (countname !== countdob) {
			count = countname < countdob ? countname:countdob
		} else {
			count = countname
		}

		playerCountDOM.setAttribute('players-count', count);
		
		formAdd.classList.add('hide-button');

		if(playerCountDOM.getAttribute('players-count') < 12) {
			formAdd.classList.remove('hide-button')
		} else {
			document.querySelector('#maxPlayers').classList.remove('hide-button');
		}
	})

}

</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>